<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="img/transparentlogo-green.png">
    <title>Galéria</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body id="gallery-body" class="prevent-select">
    <main>
        <div id="navbar">
            <nav>
                <h2 class="logo">Irinyi <span>BarberShop</span></h2>
                <ul>
                    <li><a href="index.php">Főoldal</a></li>
                    <li><a href="about.php">Rólunk</a></li>
                    <li><a href="gallery.php" class="active">Galéria</a></li>
                    <li><a href="pricelist.php">Árlista</a></li>
                    <li><a href="booking.php">Időpontfoglalás</a></li>
                    <li><a href="contact.php">Elérhetőség</a></li>
                </ul>
                <a href="login.php" class="button">Bejelentkezés</a>
            </nav>
        </div>
        <br>
        <div class="gallery-h1">
            <h1>Munkáink</h1>
        </div>
        <br>
        <div id="image-track" data-mouse-down-at="0" data-prev-precentage="0">
            <img class="image" src="img/first.jpg" alt="noAlt" draggable="false">
            <img class="image" src="img/second.jpg" alt="noAlt" draggable="false">
            <img class="image" src="img/third.jpg" alt="noAlt" draggable="false">
            <img class="image" src="img/fourth.jpg" alt="noAlt" draggable="false">
            <img class="image" src="img/fifth.jpg" alt="noAlt" draggable="false">
            <img class="image" src="img/seventh.jpg" alt="noAlt" draggable="false">
            <img class="image" src="img/sixth.jpg" alt="noAlt" draggable="false">
            <img class="image" src="img/eight.jpg" alt="noAlt" draggable="false">
        </div>
        <script src="js/gallery.js"></script>
    </main>
</body>

</html>