const track = document.getElementById("image-track");

let isDragging = false;
let initialX = 0;
let prevPercentage = 0;

document.addEventListener("mousedown", e => {

    if (!e.target.closest(".image")) return;

    isDragging = true;
    initialX = e.clientX;
    prevPercentage = parseFloat(track.dataset.prevPercentage) || 0;
});

document.addEventListener("mousemove", e => {
    if (!isDragging) return;

    const mouseDelta = e.clientX - initialX;
    const maxDelta = window.innerWidth / 2;
    const percentage = (mouseDelta / maxDelta) * 50;
    let nextPercentage = prevPercentage + percentage;

    nextPercentage = Math.min(nextPercentage, 0);
    nextPercentage = Math.max(nextPercentage, -100);

    track.dataset.prevPercentage = nextPercentage;
    track.style.transform = `translate(${nextPercentage}%, -50%)`;

    for (const image of track.getElementsByClassName("image")) {
        image.style.backgroundPosition = `${100 + nextPercentage}% 50%`;
    }
});

document.addEventListener("mouseup", () => {
    isDragging = false;
});