<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="img/transparentlogo-green.png">
    <title>Főoldal</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body id="index-body" class="prevent-select">
    <main>
        <div id="navbar">
            <nav>
                <h2 class="logo">Irinyi <span>BarberShop</span></h2>
                <ul>
                    <li><a href="index.php" class="active">Főoldal</a></li>
                    <li><a href="about.php">Rólunk</a></li>
                    <li><a href="gallery.php">Galéria</a></li>
                    <li><a href="pricelist.php">Árlista</a></li>
                    <li><a href="booking.php">Időpontfoglalás</a></li>
                    <li><a href="contact.php">Elérhetőség</a></li>
                </ul>
                <a href="login.php" class="button">Bejelentkezés</a>
            </nav>
        </div>
        <div>
            <h1>Irinyi <span>BarberShop</span></h1>
        </div>
        <br>
        <div class="bio">
            <h3>AZ INFORMATIKUSOK ELSŐ SZÁMÚ BORBÉLYMŰHELYE</h3>
            <br>
            <p>6725 SZEGED, TISZA LAJOS KÖRÚT 103.</p>
        </div>
        <div id="index-contact">
            <h2>Foglalj időpontot!</h2>
            <p><b>János: </b>(+36/20) 128-1657</p>
            <p><b>Márk: </b>(+36/30) 666-6969</p>
            <p><b>Pál: </b>(+36/70) 911-8249</p>
        </div>
    </main>
</body>

</html>