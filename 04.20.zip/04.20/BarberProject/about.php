<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="img/transparentlogo-green.png">
    <title>Rólunk</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body id="about-body" class="prevent-select">
    <main>
        <div id="navbar">
            <nav>
                <h2 class="logo">Irinyi <span>BarberShop</span></h2>
                <ul>
                    <li><a href="index.php">Főoldal</a></li>
                    <li><a href="about.php" class="active">Rólunk</a></li>
                    <li><a href="gallery.php">Galéria</a></li>
                    <li><a href="pricelist.php">Árlista</a></li>
                    <li><a href="booking.php">Időpontfoglalás</a></li>
                    <li><a href="contact.php">Elérhetőség</a></li>
                </ul>
                <a href="login.php" class="button">Bejelentkezés</a>
            </nav>
        </div>

        <div id="table-container">
            <table>
                <tr>
                    <td class="about-left">
                        <h3>Minta János - Az Alkotó Művész</h3>
                        <br>
                        <p>
                            Jani a csapat kreatív zsenije, aki mindig új és izgalmas frizurákkal lepi meg a vendégeket.
                            A hajvágás nem csak szakma, hanem művészet is számára.
                            Képes megtalálni az egyéniséghez leginkább illő stílust,
                            és minden egyes vágása valódi alkotás.
                            Kifinomult érzéke van a divathoz és az aktuális trendekhez,
                            így mindig képes friss és inspiráló ötleteket adni mind a csapatnak, mind a vendégeknek.
                        </p>
                    </td>
                    <td><img src="img/barber1.jpg" class="about-img" alt="NoAlt"></td>
                </tr>
                <tr>
                    <td colspan="2" class="spanned"></td>
                </tr>
                <tr>
                    <td><img src="img/barber2.jpg" class="about-img" alt="NoAlt"></td>
                    <td class="about-right">
                        <h3>Meow Márk - A Bölcs Tanácsadó</h3>
                        <br>
                        <p>
                            Márk a csapat legrutinosabb tagja, aki hatalmas tapasztalattal rendelkezik a szakmában.
                            Ő az, akit mindenki tanácsért keres,
                            legyen az új vágás vagy a megfelelő hajápolási termék kiválasztása.
                            Márk nem csak a hajhoz ért, hanem életbölcsességeivel és humorával is színezni tudja a
                            műhely hangulatát.
                            Mindig van egy története vagy jó tanácsa a zsebében, ami sokszor átsegíti az embereket nehéz
                            időszakokon.
                        </p>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" class="spanned"></td>
                </tr>
                <tr>
                    <td class="about-left">
                    <h3>Kala Pál - Az Energikus Bájos Mosoly</h3>
                    <br>
                        <p>
                            Pali a csapat energiabombája, akinek a mosolya és pozitív kisugárzása azonnal meghódítja az
                            embereket.
                            Ő a szalon hangulatának motorja, mindig vidáman és lelkesen vág bele a munkába.
                            Pali képes felvidítani még a legkomorabb vendégeket is, és mindig azon van,
                            hogy a szalon egy olyan hely legyen, ahol mindenki jól érzi magát.
                            Emellett rendkívül ügyes a hajvágásban is, és a vendégek mindig elégedetten távoznak a
                            szalonból
                            a Pali által készített frizurával.
                        </p>
                    </td>
                    <td><img src="img/barber3.jpg" class="about-img" alt="NoAlt"></td>
                </tr>
            </table>
        </div>
    </main>
</body>
</html>