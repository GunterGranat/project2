<?php
if(isset($_GET['date'])) { $date = $_GET['date'];}

if(isset($_POST['submit'])){

    if(isset($_POST['name'])){
        $name = $_POST['name'];
    }
    if(isset($_POST['email'])){
        $email = $_POST['email'];
    }
    if(isset($_POST['service'])){

        $service = $_POST['service'];

        switch ($service){
            case 0:
                $service = "NEM SPECIALIZÁLT";
                break;
            case 1:
                $service = "MOSÁS & BEÁLLÍTÁS";
                break;
            case 2:
                $service = "HAJVÁGÁS GÉPPEL (EGY MÉRET)";
                break;
            case 3:
                $service = "HAJVÁGÁS";
                break;
            case 4:
                $service = "SPECIÁLIS HAJVÁGÁS";
                break;
            case 5:
                $service = "HAJFESTÉS";
                break;
            case 6:
                $service = "SZAKÁLL IGAZÍTÁS";
                break;
            case 7:
                $service = "SZAKÁLL FESTÉS";
                break;
            case 8:
                $service = "MELEG TÖRÜLKÖZŐS BOROTVÁLÁS";
                break;
            default:
                $service = "NEM SPECIALIZÁLT";
        }
    }


    $mysqli = new mysqli("localhost", "root", "", "bookingcalendar");

    if ($mysqli->connect_error) {
        die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
    }

    $stmt = $mysqli->prepare("INSERT INTO bookings(name, email, service, date) VALUES(?,?,?,?)");
    $stmt->bind_param("ssss", $name, $email, $service, $date);

    if ($stmt->execute()) {
        $msg = "<div style='
                            color: #34eb86;
                            width: 33%;
                            text-align: center;
                            margin: auto;'>Sikeres Foglalás</div>";
    } else {
        $msg = "<div style='
                            color: red;
                            width: 33%;
                            text-align: center;
                            text-transform: uppercase;
                            margin: auto;'>Sikertelen Foglalás: " . $stmt->error . "</div>";
    }
    $stmt->close();
    $mysqli->close();

    /* if(strcmp($msg, "Sikeres Foglalás")){
        sleep(2);
        header('Location: ../booking.php');
    }*/
}

$duration = 60;
$cleanup = 0;
$start = "09:00";
$end = "17:00";

function timeslots($duration, $cleanup, $start, $end){
    $start = new DateTime($start);
    $end = new DateTime($end);
    $interval = new DateInterval('PT'.$duration."M");
    $cleanupInterval = new DateInterval('PT'.$cleanup.'M');
    $slots = array();

    for($i = $start; $i <= $end; $i->add($interval)->add($cleanupInterval)){
        $endPeriod = clone $i;
        $endPeriod->add($interval);

        if ($endPeriod>$end){
            break;
        }
        $slots[] = $i->format("H:i")."-".$endPeriod->format("H:i");
    }

    return $slots;
}
?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../img/transparentlogo-green.png">
    <title>Dátumra Foglalás</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body id="book-body" class="prevent-select">
    <main>
        <div id="navbar">
            <nav>
                <h2 class="logo">Irinyi <span>BarberShop</span></h2>
                <ul>
                    <li><a href="../index.php">Főoldal</a></li>
                    <li><a href="../about.php">Rólunk</a></li>
                    <li><a href="../gallery.php">Galéria</a></li>
                    <li><a href="../pricelist.php">Árlista</a></li>
                    <li><a href="../booking.php" class="active">Időpontfoglalás</a></li>
                    <li><a href="../contact.php">Elérhetőség</a></li>
                </ul>
                <a href="../login.php" class="button">Bejelentkezés</a>
            </nav>
        </div>

        <div style="width: 50%;
                    margin: 5% auto;
                    z-index: 0;
                    text-align: center;
                    color:white;" id="container">
            <?php echo isset($msg)?$msg:""; ?>
            <h1 style="text-align: center;">Időpont Foglalása: <?php echo $date?></h1>
            <br>
            <hr>
            <br>
            <?php
            $timeslots = timeslots($duration, $cleanup, $start, $end);
            foreach ($timeslots as $ts) {
                ?>
                <div>
                    <button class="bookit" onclick="showForm(1)" value="<?php echo $timeslots;?>"><?php echo $ts;?></button>
                </div>
            <?php } ?>
            <br>
            <hr>
            <br>
            <form action="" method="POST" autocomplete="off" id="bookForm">
                <div class="form-item">
                    <label for="timestamp">Időpont: </label>
                    <input type="text" name="timestamp" id="timestamp" value="<?php echo $ts;?>" required>
                </div>
                <div class="form-item">
                    <label for="name">Teljes név: </label>
                    <input type="text" name="name" id="name" required>
                </div>
                <div class="form-item">
                    <label for="email">E-mail cím:</label>
                    <input type="email" name="email" id="email" required>
                </div>
                <div class="form-item">
                    <label for="service">Szolgáltatás:</label>
                    <select id="service" name="service" required>
                        <option value="0" selected>VÁLASSZ SZOLGÁLTATÁST</option>
                        <option value="1">MOSÁS & BEÁLLÍTÁS</option>
                        <option value="2">HAJVÁGÁS GÉPPEL (EGY MÉRET)</option>
                        <option value="3">HAJVÁGÁS</option>
                        <option value="4">SPECIÁLIS HAJVÁGÁS</option>
                        <option value="5">HAJFESTÉS</option>
                        <option value="6">SZAKÁLL IGAZÍTÁS</option>
                        <option value="7">SZAKÁLL FESTÉS</option>
                        <option value="8">MELEG TÖRÜLKÖZŐS BOROTVÁLÁS</option>
                    </select>
                </div>
                <button type="submit" name="submit">Foglal</button>
            </form>
        </div>

        <script type="text/javascript">
            window.onload = function() {
                document.getElementById("bookForm").style.display = "none";
            };

            function showForm(a) {
                if (a === 1) {
                    document.getElementById("bookForm").style.display = "";
                }
            }
        </script>
    </main>
</body>
</html>