<?php
include "functions/functions.php";
$message = "";
if(isset($_POST["login"])){
    $uzenet = "Sikertelen bejelentkezés!";
    if(!empty(trim($_POST["username"])) && !empty(trim($_POST["password"]))){
        $users = load_users("json/users.json");
        foreach($users["users"] as $u){
            if($u["username"] === $_POST["username"] && password_verify($_POST["password"], $u["password"])){
                header("Location: index.php");
                $message = "Sikeresen bejelentkeztél";
                $_SESSION["user"] = $u;
                break;
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="img/transparentlogo-green.png">
    <title>Bejelentkezés</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body id="login-body" class="prevent-select">
    <main>
        <div id="navbar">
            <nav>
                <h2 class="logo">Irinyi <span>BarberShop</span></h2>
                <ul>
                    <li><a href="index.php">Főoldal</a></li>
                    <li><a href="about.php">Rólunk</a></li>
                    <li><a href="gallery.php">Galéria</a></li>
                    <li><a href="pricelist.php">Árlista</a></li>
                    <li><a href="booking.php">Időpontfoglalás</a></li>
                    <li><a href="contact.php">Elérhetőség</a></li>
                </ul>
                <a href="admin.php" class="button">Admin</a>
            </nav>
        </div>
        <div class="login-card-container">
            <div class="login-card">
                <div class="login-card-logo">
                    <img src="img/transparentlogo-green.png" alt="logo">
                </div>

                <div class="login-card-header">
                    <h1>Bejelentkezés</h1>
                </div>

                <form method="POST" class="login-card-form" action="functions/functions.php">

                    <div class="form-item">
                        <label style="font-weight: bold;" for="username">Felhasználó név: </label>
                        <input type="text" placeholder="Írd be a felhasználóneved!" id="username" autofocus>
                    </div>

                    <div class="form-item">
                        <label style="font-weight: bold;" for="password">Jelszó: </label>
                        <input type="password" placeholder="Írd be a jelszavad!" id="password">
                    </div>

                    <button type="submit" id="login-button" name="login">BEJELENTKEZÉS</button>
                </form>

                    <div class="login-card-footer">
                        Még nincs fiókod? <a href="registration.php">Regisztráció!</a>
                    </div>

                </div>
            </div>
    </main>
</body>

</html>