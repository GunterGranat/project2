<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="img/transparentlogo-green.png">
    <title>Elérhetőség</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body id="contact-body" class="prevent-select">
    <main>
        <div id="navbar">
            <nav>
                <h2 class="logo">Irinyi <span>BarberShop</span></h2>
                <ul>
                    <li><a href="index.php">Főoldal</a></li>
                    <li><a href="about.php">Rólunk</a></li>
                    <li><a href="gallery.php">Galéria</a></li>
                    <li><a href="pricelist.php">Árlista</a></li>
                    <li><a href="booking.php">Időpontfoglalás</a></li>
                    <li><a href="contact.php" class="active">Elérhetőség</a></li>
                </ul>
                <a href="login.php" class="button">Bejelentkezés</a>
            </nav>
        </div>
        
        <div id="contact-info">
            <table>
                <tr>
                    <td>
                        <div id="map-container">
                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2402.598171086123!2d20.14519244569628!3d46.246853947435!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4744886557ac1407%3A0x8ef6cdceb30443a2!2sSzegedi%20Tudom%C3%A1nyegyetem%20Irinyi%20%C3%A9p%C3%BClet!5e0!3m2!1shu!2shu!4v1710244286090!5m2!1shu!2shu" id="map" allowfullscreen="" referrerpolicy="no-referrer-when-downgrade">
                            </iframe>
                        </div>
                    </td>
                    <td>
                        <div id="info-container">
                            <h1 class="name">Irinyi Barbershop</h1>

                            <p class="location">6725 Szeged, Tisza Lajos körút 103.</p>
                            <a href="https://facebook.com" target="_blank"><img src="img/facebook.png" alt="noAlt" class="contact-logo"></a>
                            <a href="https://instagram.com" target="_blank"><img src="img/instagram.png" alt="noAlt" class="contact-logo"></a>
                            <p class="phone-number">(+36/20) 128-1657</p>
                            <p class="email">irinyibshop@ibshop.com</p>
                            <br>

                            <h3 class="name">Minta János</h3>
                            <a href="https://facebook.com" target="_blank"><img src="img/facebook.png" alt="noAlt" class="contact-logo"></a>
                            <a href="https://instagram.com" target="_blank"><img src="img/instagram.png" alt="noAlt" class="contact-logo"></a>
                            <p class="phone-number">(+36/30) 666-6969</p>
                            <p class="email">mintajani@ibshop.com</p>
                            <br>

                            <h3 class="name">Meow Márk</h3>
                            <a href="https://facebook.com" target="_blank"><img src="img/facebook.png" alt="noAlt" class="contact-logo"></a>
                            <a href="https://instagram.com" target="_blank"><img src="img/instagram.png" alt="noAlt" class="contact-logo"></a>
                            <p class="phone-number">(+36/70) 911-8249</p>
                            <p class="email">uwumark@ibshop.com</p>
                            <br>

                            <h3 class="name">Kala Pál</h3>
                            <a href="https://facebook.com" target="_blank"><img src="img/facebook.png" alt="noAlt" class="contact-logo"></a>
                            <a href="https://instagram.com" target="_blank"><img src="img/instagram.png" alt="noAlt" class="contact-logo"></a>
                            <p class="phone-number">(+36/30) 528-1009</p>
                            <p class="email">ak47pali@ibshop.com</p>    
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </main>
</body>

</html>