<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="img/transparentlogo-green.png">
    <title>Admin</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body id="admin-body" class="prevent-select">
    <main>
        <div id="navbar">
            <nav>
                <h2 class="logo">Irinyi <span>BarberShop</span></h2>
                <ul>
                    <li><a href="index.php">Főoldal</a></li>
                    <li><a href="about.php">Rólunk</a></li>
                    <li><a href="gallery.php">Galéria</a></li>
                    <li><a href="pricelist.php">Árlista</a></li>
                    <li><a href="booking.php">Időpontfoglalás</a></li>
                    <li><a href="contact.php">Elérhetőség</a></li>
                </ul>
                <a href="login.php" class="button">Bejelentkezés</a>
            </nav>
        </div>

        <div class="login-card-container">
            <div class="login-card">
                <div class="login-card-logo">
                    <img src="img/transparentlogo-green.png" alt="logo">
                </div>

                <div class="login-card-header">
                    <h1>Admin</h1>
                </div>

                <form class="login-card-form">

                    <div class="form-item">
                        <label style="font-weight: bold;" for="adminusername">Admin felhasználónév</label>
                        <input type="text" placeholder="admin" id="adminusername" autofocus required>
                    </div>

                    <div class="form-item">
                        <label style="font-weight: bold;" for="adminpassword">Admin jelszó</label>
                        <input type="text" placeholder="********" id="adminpassword" required>
                    </div>

                    <button type="submit" id="login-button">BEJELENTKEZÉS</button>
                </form>

            </div>
        </div>
    </main>
</body>

</html>