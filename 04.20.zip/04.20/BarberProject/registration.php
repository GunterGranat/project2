<?php

include "functions/functions.php";              // beágyazzuk a load_users() és save_users() függvényeket tartalmazó PHP fájlt
$fiokok = load_users("users.json"); // betöltjük a regisztrált felhasználók adatait, és eltároljuk őket a $fiokok változóban

$hibak = [];

if (isset($_POST["regiszt"])) {
    if (!isset($_POST["felhasznalonev"]) || trim($_POST["felhasznalonev"]) === "")
        $hibak[] = "A felhasználónév megadása kötelező!";

    if (!isset($_POST["jelszo"]) || trim($_POST["jelszo"]) === "" || !isset($_POST["jelszo2"]) || trim($_POST["jelszo2"]) === "")
        $hibak[] = "A jelszó és az ellenőrző jelszó megadása kötelező!";

    if (!isset($_POST["eletkor"]) || trim($_POST["eletkor"]) === "")
        $hibak[] = "Az életkor megadása kötelező!";

    if (!isset($_POST["nem"]) || trim($_POST["nem"]) === "")
        $hibak[] = "A nem megadása kötelező!";

    if (!isset($_POST["hobbik"]) || count($_POST["hobbik"]) < 2)
        $hibak[] = "Legalább 2 hobbit kötelező kiválasztani!";

    $felhasznalonev = $_POST["felhasznalonev"];
    $jelszo = $_POST["jelszo"];
    $jelszo2 = $_POST["jelszo2"];
    $eletkor = $_POST["eletkor"];
    $nem = NULL;
    $hobbik = NULL;

    if (isset($_POST["nem"]))
        $nem = $_POST["nem"];
    if (isset($_POST["hobbik"]))
        $hobbik = $_POST["hobbik"];

    foreach ($fiokok["users"] as $fiok) {
        if ($fiok["felhasznalonev"] === $felhasznalonev)
        $hibak[] = "A felhasználónév már foglalt!";
    }

    if (strlen($jelszo) < 5)
        $hibak[] = "A jelszónak legalább 5 karakter hosszúnak kell lennie!";

    if ($jelszo !== $jelszo2)
        $hibak[] = "A jelszó és az ellenőrző jelszó nem egyezik!";

    if ($eletkor < 18)
        $hibak[] = "Csak 18 éves kortól lehet regisztrálni!";

    if (count($hibak) === 0) {   // sikeres regisztráció
        $jelszo = password_hash($jelszo, PASSWORD_DEFAULT);       // jelszó hashelése
        // hozzáfűzzük az újonnan regisztrált felhasználó adatait a rendszer által ismert felhasználókat tároló tömbhöz
        $fiok = [
            "username" => $felhasznalonev,
            "password" => $jelszo,
            "age" => $eletkor,
            "gender" => $nem,
            "hobbies" => $hobbik
        ];
        // elmentjük a kibővített $fiokok tömböt a users.json fájlba
        save_users("users.json", $fiok);
        $siker = TRUE;
    } else {                    // sikertelen regisztráció
        $siker = FALSE;
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="img/transparentlogo-green.png">
    <title>Regisztráció</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body id="registration-body" class="prevent-select">
    <main>
        <div id="navbar">
            <nav>
                <h2 class="logo">Irinyi <span>BarberShop</span></h2>
                <ul>
                    <li><a href="index.php">Főoldal</a></li>
                    <li><a href="about.php">Rólunk</a></li>
                    <li><a href="gallery.php">Galéria</a></li>
                    <li><a href="pricelist.php">Árlista</a></li>
                    <li><a href="booking.php">Időpontfoglalás</a></li>
                    <li><a href="contact.php">Elérhetőség</a></li>
                </ul>
                <a href="login.php" class="button">Bejelentkezés</a>
            </nav>
        </div>

        <div class="registration-card-container">
            <div class="registration-card">
                <div class="registration-card-logo">
                    <img src="img/transparentlogo-green.png" alt="logo">
                </div>

                <div class="registration-card-header">
                    <h1>Regisztráció</h1>
                </div>

                <form method="POST" action="functions/functions.php" class="registration-card-form">

                    <div class="form-item">
                        <label style="font-weight: bold;" for="username">Felhasználó név:</label>
                        <input type="text" placeholder="Írd be a felhasználóneved!" id="username" autofocus>
                    </div>

                    <div class="form-item">
                        <label style="font-weight: bold;" for="fullname">Teljes név:</label>
                        <input type="text" placeholder="Írd be a teljes neved!" id="fullname">
                    </div>

                    <div class="form-item">
                        <label style="font-weight: bold;" for="email">E-mail cím:</label>
                        <input type="email" placeholder="Írd be az e-mail címed!" id="email">
                    </div>

                    <div class="form-item">
                        <label style="font-weight: bold;" for="password">Jelszó:</label>
                        <input type="password" placeholder="Írd be a jelszavad!" id="password">
                    </div>

                    <div class="form-item">
                        <label style="font-weight: bold;" for="repassword">Jelszó megerősítése:</label>
                        <input type="password" placeholder="Írd be újra a jelszavad!" id="repassword">
                    </div>

                    <button type="submit" id="registration-button" name="regist">REGISZTRÁLOK</button>
                </form>

                <div class="registration-card-footer">
                    Már van fiókod? <a href="login.php">Bejelentkezés!</a>
                </div>
            </div>
        </div>
    </main>
</body>

</html>