<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="img/transparentlogo-green.png">
    <title>Szerkesztés</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body id="profile-body" class="prevent-select">
    <main>
        <div id="navbar">
            <nav>
                <h2 class="logo">Irinyi <span>BarberShop</span></h2>
                <ul>
                    <li><a href="index.php">Főoldal</a></li>
                    <li><a href="about.php">Rólunk</a></li>
                    <li><a href="gallery.php">Galéria</a></li>
                    <li><a href="pricelist.php">Árlista</a></li>
                    <li><a href="booking.php">Időpontfoglalás</a></li>
                    <li><a href="contact.php">Elérhetőség</a></li>
                </ul>
                <a href="profile.php" class="button">PROFIL</a>
            </nav>
        </div>
        <div class="login-card-container">
            <div class="login-card">
                <div class="login-card-logo">
                    <img src="img/avatarplaceholder.png" alt="logo">
                </div>

                <div class="login-card-header">
                    <h1>Szerkesztés</h1>
                </div>

                <form class="login-card-form">
                    <div class="form-item">
                        <label style="font-weight: bold;" for="username">Felhasználónév:</label>
                        <input type="text" id="username" value="valamiminta" required>
                    </div>

                    <div class="form-item">
                        <label style="font-weight: bold;" for="fullname">Teljes név:</label>
                        <input type="text" id="fullname" value="Valami Minta" required>
                    </div>

                    <div class="form-item">
                        <label style="font-weight: bold;" for="email">Email-cím:</label>
                        <input type="text" id="email" value="valamiminta@gmail.com" required>
                    </div>

                    <div class="form-item">
                        <label style="font-weight: bold;" for="password">Jelszó:</label>
                        <input type="text" placeholder="********" id="password" required>
                    </div>

                    <div class="form-item">
                        <label style="font-weight: bold;" for="repassword">Jelszó megerősítése:</label>
                        <input type="text" placeholder="********" id="repassword" required>
                    </div>

                    <a href="profile.php" id="login-button">MENTÉS</a>
                </form>

            </div>
        </div>
    </main>
</body>

</html>