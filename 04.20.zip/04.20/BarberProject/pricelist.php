<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="img/transparentlogo-green.png">
    <title>Árlista</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body id="booking-body" class="prevent-select">
    <main>
        <div id="navbar">
            <nav>
                <h2 class="logo">Irinyi <span>BarberShop</span></h2>
                <ul>
                    <li><a href="index.php">Főoldal</a></li>
                    <li><a href="about.php">Rólunk</a></li>
                    <li><a href="gallery.php">Galéria</a></li>
                    <li><a href="pricelist.php" class="active">Árlista</a></li>
                    <li><a href="booking.php">Időpontfoglalás</a></li>
                    <li><a href="contact.php">Elérhetőség</a></li>
                </ul>
                <a href="login.php" class="button">Bejelentkezés</a>
            </nav>
        </div>

        <div id="pricelist">
            <h2>Árlista</h2>
            <hr class="title-hr">

            <h3 class="prices-h3"><span>MOSÁS & BEÁLLÍTÁS</span> - 2.500 FT</h3>
            <p class="prices-bio">Üzleti tárgyalás vagy esti randevú? Gyors mosást és vérprofi beállítást kapsz mellyel
                új szintre emelheted megjelenésed.
            </p>
            <hr class="bio-hr">

            <h3 class="prices-h3"><span>HAJVÁGÁS GÉPPEL (EGY MÉRET)</span> - 4.000 FT</h3>
            <p class="prices-bio">Egyszerűség és maximalizmus. Vágasd frizurádat géppel egy méretre.
            </p>
            <hr class="bio-hr">

            <h3 class="prices-h3"><span>HAJVÁGÁS</span> - 4.800 FT</h3>
            <p class="prices-bio">Professzionális barber hajvágás egyéniségedhez szabva.
            </p>
            <hr class="bio-hr">

            <h3 class="prices-h3"><span>SPECIÁLIS HAJVÁGÁS</span> - 6.000 FT</h3>
            <p class="prices-bio">Formabontó frizurát csinálunk Neked, legyen szó extrém vonalakról vagy beállításról...
            </p>
            <hr class="bio-hr">

            <h3 class="prices-h3"><span>HAJFESTÉS</span> - 3.500 FT-TÓL</h3>
            <p class="prices-bio">Egyedülálló megjelenés kedvenc színeddel. Az ár a felvitt festék mennyiségétől függ.
            </p>
            <hr class="bio-hr">

            <h3 class="prices-h3"><span>SZAKÁLL IGAZÍTÁS</span> - 3.300 FT</h3>
            <p class="prices-bio">Egy karbantartott és igényes szakállhoz professzionális szakértelem kell. Mi a
                legjobbat hozzuk szakálladból: Törődés, prémium termékek és szakképzett borbélyok.</p>
            <hr class="bio-hr">

            <h3 class="prices-h3"><span>SZAKÁLL FESTÉS</span> - 3.000 FT-TÓL</h3>
            <p class="prices-bio">Elegáns szakáll a kedvenc választott színeddel. Az ár a felvitt festék mennyiségétől
                függ.</p>
            <hr class="bio-hr">

            <h3 class="prices-h3"><span>MELEG TÖRÜLKÖZŐS BOROTVÁLÁS</span> - 4.500 FT</h3>
            <p class="prices-bio">Tradicionális melegtörülközős borotválás nyelesborotvával. A végeredmény tökéletesen
                sima és friss arc.</p>
            <hr class="bio-hr">
        </div>
    </main>
</body>

</html>