<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="img/transparentlogo-green.png">
    <title>Profil</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body id="profile-body" class="prevent-select">
    <main>
        <div id="navbar">
            <nav>
                <h2 class="logo">Irinyi <span>BarberShop</span></h2>
                <ul>
                    <li><a href="index.php">Főoldal</a></li>
                    <li><a href="about.php">Rólunk</a></li>
                    <li><a href="gallery.php">Galéria</a></li>
                    <li><a href="pricelist.php">Árlista</a></li>
                    <li><a href="booking.php">Időpontfoglalás</a></li>
                    <li><a href="contact.php">Elérhetőség</a></li>
                </ul>
                <a href="edit.php" class="button">SZERKESZTÉS</a>
            </nav>
        </div>

        <div class="login-card-container">
            <div class="login-card">
                <div class="login-card-logo">
                    <img src="img/avatarplaceholder.png" alt="logo">
                </div>

                <div class="login-card-header">
                    <h1>Profilom</h1>
                </div>

                <div class="login-card-form">

                    <div class="form-item">
                        <p style="font-weight: bold;">Felhasználónév:</p>
                        <p>valamiminta</p>
                    </div>

                    <div class="form-item">
                        <p style="font-weight: bold;">Teljes név:</p>
                        <p>Valami Minta</p>
                    </div>

                    <div class="form-item">
                        <p style="font-weight: bold;">E-mail cím:</p>
                        <p>valamiminta@gmail.com</p>
                    </div>

                    <a href="edit.php" id="login-button">SZERKESZTÉS</a>
                </div>
            </div>
        </div>
    </main>
</body>

</html>